const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// تحميل صورة من جهاز المستخدم
document
  .getElementById("image-upload")
  .addEventListener("change", function (event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
      const img = new Image();
      img.onload = function () {
        ctx.clearRect(0, 0, canvas.width, canvas.height); // تنظيف قبل الإضافة
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height); // رسم الصورة
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });

// إضافة شعار من رابط URL
function addLogo() {
  const url = document.getElementById("logo-url").value;
  const img = new Image();
  img.crossOrigin = "anonymous"; // لتفادي مشاكل الأمان مع الصور
  img.onload = function () {
    ctx.drawImage(img, 50, 50, 100, 100); // وضع الشعار في موقع ثابت
  };
  img.src = url;
}

// إضافة نص مع خيارات التنسيق
function addText() {
  const text = document.getElementById("text-input").value;
  const color = document.getElementById("font-color").value;
  const fontSize = document.getElementById("font-size").value;

  ctx.fillStyle = color;
  ctx.font = `${fontSize}px Arial`; // ضبط نوع وحجم الخط
  ctx.fillText(text, 50, 300); // رسم النص في مكان معين
}
function saveDesign() {
  const link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = "my-design.png";
  link.click();
}
function goBack() {
  window.location.href = "index.html"; // توجيه إلى الصفحة الرئيسية أو صفحة المنتجات
}

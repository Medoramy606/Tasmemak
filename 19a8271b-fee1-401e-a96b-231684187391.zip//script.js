function showSignUp() {
  document.getElementById("sign-up-form").style.display = "block";
  document.getElementById("login-form").style.display = "none";
}

function showLogin() {
  document.getElementById("login-form").style.display = "block";
  document.getElementById("sign-up-form").style.display = "none";
}
// تسجيل بيانات المستخدم عند النقر على زر "Sign Up"
function handleSignUp(event) {
  event.preventDefault(); // لمنع تحديث الصفحة

  const username = document.getElementById("signup-username").value;
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  const confirmPassword = document.getElementById(
    "signup-confirm-password"
  ).value;

  // التحقق من تطابق كلمتي المرور
  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return;
  }

  // حفظ بيانات المستخدم في Local Storage
  const userData = {
    username: username,
    email: email,
    password: password,
  };
  localStorage.setItem(email, JSON.stringify(userData));

  alert("Sign up successful! You can now log in.");
  showLogin(); // تحويل المستخدم إلى نموذج تسجيل الدخول بعد التسجيل
}

// التحقق من بيانات المستخدم عند النقر على زر "Login"
function handleLogin(event) {
  event.preventDefault(); // لمنع تحديث الصفحة

  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  // استرجاع بيانات المستخدم من Local Storage
  const storedUser = localStorage.getItem(email);

  if (!storedUser) {
    alert("User not found. Please sign up.");
    return;
  }

  const userData = JSON.parse(storedUser);

  // التحقق من صحة كلمة المرور
  if (userData.password === password) {
    alert("Login successful! Welcome, " + userData.username + "!");
    // يمكنك هنا توجيه المستخدم إلى صفحة أخرى بعد تسجيل الدخول
  } else {
    alert("Incorrect password. Please try again.");
  }
}

// ربط الدوال مع الأزرار في النماذج
document
  .querySelector("#sign-up-form form")
  .addEventListener("submit", handleSignUp);
document
  .querySelector("#login-form form")
  .addEventListener("submit", handleLogin);
function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;
  const storedUser = localStorage.getItem(email);

  if (!storedUser) {
    alert("User not found. Please sign up.");
    return;
  }

  const userData = JSON.parse(storedUser);
  if (userData.password === password) {
    alert("Login successful! Welcome, " + userData.username + "!");
    window.location.href = "design.html"; // توجيه المستخدم إلى صفحة اختيار الملابس
  } else {
    alert("Incorrect password. Please try again.");
  }
}

function startDesign(item) {
  alert("You have chosen: " + item + ". Starting design...");
  // يمكنك هنا توجيه المستخدم إلى صفحة التصميم الخاصة بالقطعة المختارة
}
function handleSignUp(event) {
  event.preventDefault();

  const username = document.getElementById("signup-username").value;
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  const confirmPassword = document.getElementById(
    "signup-confirm-password"
  ).value;

  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return;
  }

  const userData = {
    username: username,
    email: email,
    password: password,
  };
  localStorage.setItem(email, JSON.stringify(userData));

  alert("Sign up successful! Welcome, " + username + "!");
  window.location.href = "design.html"; // توجيه المستخدم إلى صفحة اختيار الملابس بعد التسجيل
}

function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  const storedUser = localStorage.getItem(email);

  if (!storedUser) {
    alert("User not found. Please sign up.");
    return;
  }

  const userData = JSON.parse(storedUser);

  if (userData.password === password) {
    alert("Login successful! Welcome, " + userData.username + "!");
    window.location.href = "design.html"; // توجيه المستخدم إلى صفحة اختيار الملابس بعد تسجيل الدخول
  } else {
    alert("Incorrect password. Please try again.");
  }
}

function startDesign(item) {
  alert("You have chosen: " + item + ". Starting design...");
  // هنا يمكنك إضافة توجيه أو أدوات تخصيص التصميم لاحقًا
}
function startDesign(item) {
  // حفظ اسم القطعة المختارة في localStorage لتذكرها لاحقًا
  localStorage.setItem("selectedItem", item);
  // توجيه المستخدم إلى صفحة التصميم
  window.location.href = "customize.html";
}
